#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <list>
#include <unordered_map>

using namespace std;

int main(int argc, char *argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <filename>" << endl;
        return 1;
    }

    // Open the file
    ifstream file(argv[1]);
    if (!file.is_open()) {
        cerr << "Failed to open file." << endl;
        return 1;
    }

    // List to store addresses
    list<int> addresses;

    // Read addresses from the file
    int address;
    while (file >> address) {
        addresses.push_back(address);
    }

    // Close the file
    file.close();

    // Constants
    const string BACKING_STORE = "BACKING_STORE.bin";
    const int pageTableSize = 256;
    const int tlbSize = 16;
    const int physicalMemorySize = 256;
    int nextFrame = 0;
    int addressAmount = 0;
    int pageFaults = 0;
    int tlbHits = 0;

    // TLB
    queue<int> tlb;
    unordered_map<int, int> tlbMap;

    // Page table
    int pageTable[pageTableSize];
    for (int i = 0; i < pageTableSize; ++i) {
        pageTable[i] = -1;
    }

    // Physical memory
    int physicalMemory[physicalMemorySize][physicalMemorySize];

    // Loop through addresses
    while (!addresses.empty()) {
        addressAmount++;
        int address = addresses.front();
        addresses.pop_front();

        // Extract page number and offset
        int pageNumber = address >> 8;
        int offset = address & 0xFF;

        // TLB lookup
        if (tlbMap.find(pageNumber) != tlbMap.end()) {
            int frameNumber = tlbMap[pageNumber];
            int physicalAddress = (frameNumber << 8) | offset;
            int value = physicalMemory[frameNumber][offset];
            cout << "Virtual address: " << address << " Physical address: " << physicalAddress << " Value: " << value << endl;
            tlbHits++;
        } else if (pageTable[pageNumber] != -1) {
            // Page table hit
            int frameNumber = pageTable[pageNumber];
            int physicalAddress = (frameNumber << 8) | offset;
            int value = physicalMemory[frameNumber][offset];
            cout << "Virtual address: " << address << " Physical address: " << physicalAddress << " Value: " << value << endl;

            // Update TLB
            if (tlb.size() >= tlbSize) {
                int oldestPage = tlb.front();
                tlb.pop();
                tlbMap.erase(oldestPage);
            }
            tlb.push(pageNumber);
            tlbMap[pageNumber] = frameNumber;
        } else {
            // Page fault
            pageFaults++;

            // Open backing store
            ifstream bsFile(BACKING_STORE, ios::binary);
            if (!bsFile.is_open()) {
                cerr << "Failed to open file." << endl;
                return 1;
            }

            // Seek to the correct location in backing store
            int bsOffset = pageNumber * physicalMemorySize;
            bsFile.seekg(bsOffset);

            // Read data from backing store
            vector<char> frame(physicalMemorySize);
            bsFile.read(frame.data(), physicalMemorySize);
            bsFile.close();

            // Find next available frame
            int frameNumber = nextFrame;
            nextFrame = (nextFrame + 1) % physicalMemorySize;

            // Update page table and physical memory
            pageTable[pageNumber] = frameNumber;
            for (int i = 0; i < physicalMemorySize; ++i) {
                physicalMemory[frameNumber][i] = frame[i];
            }

            // Update TLB
            if (tlb.size() >= tlbSize) {
                int oldestPage = tlb.front();
                tlb.pop();
                tlbMap.erase(oldestPage);
            }
            tlb.push(pageNumber);
            tlbMap[pageNumber] = frameNumber;

            // Calculate physical address and value
            int physicalAddress = (frameNumber << 8) | offset;
            int value = physicalMemory[frameNumber][offset];
            cout << "Virtual address: " << address << " Physical address: " << physicalAddress << " Value: " << value << endl;
        }
    }

    // Final outputs
    cout << "Number of Translated Addresses = " << addressAmount << endl;
    cout << "Page Faults = " << pageFaults << endl;
    double pageFaultRate = static_cast<double>(pageFaults) / addressAmount;
    cout << "Page Fault Rate = " << pageFaultRate << endl;

    // TLB info
    cout << "TLB Hits = " << tlbHits << endl;
    double tlbHitRate = static_cast<double>(tlbHits) / addressAmount;
    cout << "TLB Hit Rate = " << tlbHitRate << endl;

    return 0;
}
